<table class="table table-striped table-bordered table-hover">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($resource->name); ?></td>
            <td><?php echo e($resource->email); ?></td>
            <td><?php echo e($resource->phone); ?></td>
            <td><?php echo e($resource->gender); ?></td>
            <td>
                <a href="<?php echo e(route('contact.show', $resource->id)); ?>" class="btn btn-info">View</a>
                <a href="<?php echo e(route('contact.edit', $resource->id)); ?>" class="btn btn-primary">Edit</a>
                <button type="button" class="btn btn-danger" data-action="delete" data-id="<?php echo e($resource->id); ?>">Delete</button>
                <button type="button" class="btn btn-secondary" data-action="merge" data-id="<?php echo e($resource->id); ?>">Merge Contact</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $resources->links(); ?><?php /**PATH C:\xampp8.2\htdocs\zestbrain-practical\resources\views/contact/contact_partial.blade.php ENDPATH**/ ?>